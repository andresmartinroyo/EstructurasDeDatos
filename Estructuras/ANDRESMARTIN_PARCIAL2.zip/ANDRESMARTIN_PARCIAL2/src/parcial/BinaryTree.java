/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

/**
 *
 * @author Andres
 */
public class BinaryTree {

    public Node root;

    public BinaryTree() {
        this.root = null;
    }

    public boolean its_empty(Node n) {
        return n == null;
    }




    //Recorre el rbol en preorden y devuelvee el string del recorrido
    
    public String PreOrder(Node n){
        return PreOrder( n,  "");
    }
    
    public String PreOrder(Node n, String texto) {
        texto += n.get_info() + " ";
        if (n.Left_child() != null){
            PreOrder( n.Left_child(),  texto);
        }
        if (n.Right_child() != null){
            PreOrder( n.Right_child(),  texto);
        }
        
        return texto;
               
    }

    //Crea el arbol de manera recursiva, de manera de que va dividiendo los string por la mitad en el preorden, en el incio lo divide en la raiz.
    
    public void crearArbol(String rInorden, String rPost) {
        
        String subArbolIzqS = rInorden.split(String.valueOf(rPost.charAt(rPost.length() - 1)))[0];
        String subArbolDerS = rInorden.split(String.valueOf(rPost.charAt(rPost.length() - 1)))[1];
        Node raiz = new Node(String.valueOf(rPost.charAt(rPost.length() - 1)));
        this.crearArbol(raiz.Left_child(), subArbolIzqS);
        this.crearArbol(raiz.Right_child(), subArbolDerS);
        this.root = raiz;
        
    }
    
    public void crearArbol(Node padre, String recorridoIn){
        int ramas = (recorridoIn.length() / 2);
        if (ramas == 1) {
            Node pAuxHijoI = new Node(String.valueOf(recorridoIn.charAt(0)));
            Node pAuxHijoD = new Node(String.valueOf(recorridoIn.charAt(2)));
            padre.Set_info(String.valueOf(recorridoIn.charAt(1)));
            padre.Set_Left_child(pAuxHijoI);
            padre.Set_Right_child(pAuxHijoD);
        }
        else{
            String[] elementoS = recorridoIn.split(String.valueOf(recorridoIn.charAt(ramas)));
            padre.Set_info(String.valueOf(recorridoIn.charAt(ramas)));
            Node pAuxHijoI = new Node();
            Node pAuxHijoD = new Node();
            if (!elementoS[0].equals("")){
            crearArbol(pAuxHijoI,elementoS[0]);
            }
            if (!elementoS[1].equals("")){
            crearArbol(pAuxHijoD,elementoS[1]);
            }
        }
        
    }


}
