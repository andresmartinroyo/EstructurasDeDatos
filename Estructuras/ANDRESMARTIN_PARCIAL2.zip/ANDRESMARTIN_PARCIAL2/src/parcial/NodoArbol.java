/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

/**
 *
 * @author Andres
 */
public class NodoArbol {
     

    public NodoArbol pNext;
    public Node dato;

    public NodoArbol(Node dato) {
        this.dato = dato;
    }

    public NodoArbol() {

    }

}

