/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

/**
 *
 * @author Andres
 */
public class Pila {

    public Nodo pCima;
    public int size;

    public Pila() {

    }

    public boolean isEmpty() {
        return (this.pCima == null);
    }

    public void apilar(String newDato) {
        Nodo pNew = new Nodo(newDato);
        if (this.isEmpty()) {
            this.pCima = pNew;
        } else {
           pNew.pNext = pCima;
            this.pCima = pNew;
        }
        this.size++;
    }

    public String desapilar() {
        String texto = "";
        if (!this.isEmpty()) {
            texto = this.pCima.dato;
            this.pCima = this.pCima.pNext;
        }
        return texto;
    }
}
