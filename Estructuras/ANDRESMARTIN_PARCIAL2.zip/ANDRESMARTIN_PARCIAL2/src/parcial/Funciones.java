/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

/**
 *
 * @author Andres
 */
public class Funciones {

    //Revisa que sea operando
    public boolean esOperando(char elemento) {
        return (String.valueOf(elemento).equals("*") || String.valueOf(elemento).equals("+") || String.valueOf(elemento).equals("-") || String.valueOf(elemento).equals("/") || String.valueOf(elemento).equals("/"));
    }

    //Dada la expresion en polaca invers, esta la trasforma a infija. O se supone 
    public String postAIn(String operacionPost) {
        Pila pila = new Pila();
        String texto = "";
        for (int i = 0; i < operacionPost.length(); i++) {
            if (i != operacionPost.length()) {
                if ((!esOperando(operacionPost.charAt(i)))) {
                    pila.apilar(String.valueOf(operacionPost.charAt(i)));
                } else if ((esOperando(operacionPost.charAt(i))) && ((esOperando(operacionPost.charAt(i + 1))))) {
                    texto += String.valueOf(operacionPost.charAt(i + 1));
                    String operado2 = pila.desapilar();
                    String operando = String.valueOf(operacionPost.charAt(i));
                    String operado1 = pila.desapilar();
                    texto += operado1 + operando + operado2;
                    i++;
                } else if ((esOperando(operacionPost.charAt(i))) && (!(esOperando(operacionPost.charAt(i + 1))))) {

                    String operado2 = pila.desapilar();
                    String operando = String.valueOf(operacionPost.charAt(i));
                    String operado1 = pila.desapilar();
                    texto += operado1 + operando + operado2;

                }
            }
        }

        return texto;
    }
    
    //Aqui esyaba por lograrlo.
////    
//
//    public BinaryTree crearArbolPost(String operacionPost) {
//        Pila pila = new Pila();
//        PilaArbol arboles = new PilaArbol();
//        BinaryTree arbol = new BinaryTree();
//        for (int i = 0; i < operacionPost.length(); i++) {
//            Node pAux = new Node();
//            if (i != operacionPost.length()) {
//                if ((!esOperando(operacionPost.charAt(i)))) {
//                    pila.apilar(String.valueOf(operacionPost.charAt(i)));
//                } else if ((esOperando(operacionPost.charAt(i))) && ((esOperando(operacionPost.charAt(i + 1))))) {
//
//                    String operado2 = pila.desapilar();
//                    String operando = String.valueOf(operacionPost.charAt(i));
//                    String operado1 = pila.desapilar();
//
//                    Node Right = arboles.desapilar();
//                    
//                    Node left = arboles.desapilar();
//
//                    i++;
//                } else if ((esOperando(operacionPost.charAt(i))) && (!(esOperando(operacionPost.charAt(i + 1))))) {
//
//                    String operado2 = pila.desapilar();
//                    String operando = String.valueOf(operacionPost.charAt(i));
//                    String operado1 = pila.desapilar();
//                    Node Left = new Node(operado1);
//                    Node Right = new Node(operado2);
//
//                    pAux.Set_Left_child(Left);
//                    pAux.Set_Right_child(Right);
//                    pAux.Set_info(operando);
//                    arboles.apilar(pAux);
//
//                }
//            }
//        }
//
//    }
}
