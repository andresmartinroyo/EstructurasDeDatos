/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial;

/**
 *
 * @author Andres
 */
public class PilaArbol {

    public NodoArbol pCima;
    public int size;

    public PilaArbol() {

    }

    public boolean isEmpty() {
        return (this.pCima == null);
    }

    public void apilar(Node newDato) {
        NodoArbol pNew = new NodoArbol(newDato);
        if (this.isEmpty()) {
            this.pCima = pNew;
        } else {
            pNew.pNext = pCima;
            this.pCima = pNew;
        }
        this.size++;
    }

    public Node desapilar() {
        Node arbol = new Node();
        if (!this.isEmpty()) {
            arbol = this.pCima.dato;
            this.pCima = this.pCima.pNext;
        }
        return arbol;
    }
}
